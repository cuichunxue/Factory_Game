# ミミズ工場サバイバー 追加素材パック v2

スクショの優先順位に合わせて用意した素材です。

## 01_priority_high
ゲーム体験に直結する素材です。

- victory_screen/victory_screen_illustration.png
- victory_screen/victory_screen_no_text_background.png
- defeat_screen/defeat_screen_illustration.png
- defeat_screen/defeat_screen_no_text_background.png
- title_logo_transparent/game_title_logo_transparent.png

## 02_priority_medium
ポリッシュ感を上げる素材です。

- xp_orb_sprite/xp_orb_sprite_sheet_8frames.png
- auto_attack_projectile/soil_projectile_sprite_sheet_8frames.png
- audio_bgm/victory_bgm_loop_15s.wav
- audio_bgm/title_ambient_loop_18s.wav
- hit_particles/hit_particles_sprite_sheet_8frames.png

## 03_bonus
あれば加点の素材です。

- font_css_recommendation/font_css_recommendation.css
- levelup_effect/level_up_effect_sprite_sheet_10frames.png

## 補足
- カスタムフォントのフォントファイルは同梱していません。
- 代わりにCSSの推奨font-familyと、透過PNGロゴを用意しています。
- スプライトシートは横並びで、各フレームサイズはファイル名またはフォルダ内画像から確認できます。
